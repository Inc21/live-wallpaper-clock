![](/clock.png)
# live-wallpaper-clock


Clock wallpaper that updates every minute.
Runs at system startup with no command prompt visible.

### Steps
| Step | Action | Links |
|---|---|---|
| 1 | Make sure you have node.js downloaded and installed | [Download node.js](https://nodejs.org/en/download) | 
| 2 | 

Download NirCmd - to hide cmd window 
https://www.nirsoft.net/utils/nircmd.html

better explanation - https://whatsoftware.com/hidden-start-runs-batch-files-silently-without-flickering-console/